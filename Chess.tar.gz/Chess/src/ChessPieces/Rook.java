package ChessPieces;

public class Rook implements Pieces {

	private boolean isWhite;
	
	public Rook(boolean isWhite) {
		this.isWhite = isWhite;
	}
	
	public boolean getColor() {
		return this.isWhite;
	}
	
	@Override
	public String toString() {
		return "R";}

}

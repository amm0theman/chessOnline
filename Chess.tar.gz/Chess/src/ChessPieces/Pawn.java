package ChessPieces;

public class Pawn implements Pieces{

	private boolean isWhite;
	
	public Pawn(boolean isWhite) {
		this.isWhite = isWhite;
	}
	
	public boolean getColor() {
		return this.isWhite;
	}
	
	@Override
	public String toString() {
		return "P";}
}

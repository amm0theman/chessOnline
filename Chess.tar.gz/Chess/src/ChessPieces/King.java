package ChessPieces;

public class King implements Pieces{
	
	private boolean isWhite;
	
	public King(boolean isWhite) {
		this.isWhite = isWhite;
	}
	
	public boolean getColor() {
		return this.isWhite;
	}
	
	@Override
	public String toString() {
		return "K";}
}

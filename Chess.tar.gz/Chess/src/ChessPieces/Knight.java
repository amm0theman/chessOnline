package ChessPieces;

public class Knight implements Pieces {
	
	private boolean isWhite;
	
	public Knight(boolean isWhite) {
		this.isWhite = isWhite;
	}
	
	public boolean getColor() {
		return this.isWhite;
	}
	
	@Override
	public String toString() {
		return "H";}
}

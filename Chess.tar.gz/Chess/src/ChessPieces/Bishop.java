package ChessPieces;


public class Bishop implements Pieces {

	private boolean isWhite;
	
	public Bishop(boolean isWhite) {
		this.isWhite = isWhite;
	}
	
	public boolean getColor() {
		return this.isWhite;
	}
	
	@Override
	public String toString() {
		return "B";}

}

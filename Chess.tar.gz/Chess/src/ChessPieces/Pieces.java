package ChessPieces;

public interface Pieces {
		
	@Override
	public String toString();
}
